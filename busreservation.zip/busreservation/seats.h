#ifndef SEATS_H
#define SEATS_H

#include <QDialog>
#include "registration.h"

namespace Ui {
class seats;
}

class seats : public QDialog
{
    Q_OBJECT

public:
    explicit seats(QWidget *parent = 0);
    void setId(int);
    ~seats();

private slots:
  void on_s1_clicked();

  void on_bus_no_clicked();

  void on_s2_clicked();

  void on_s3_clicked();

  void on_s4_clicked();

  void on_s5_clicked();

  void on_s6_clicked();

private:
    Ui::seats *ui;
    int bus_id;
    registration *reg;
};

#endif // SEATS_H
