#ifndef DBCONNECT_H
#define DBCONNECT_H
#include<QSql>
#include<QSqlDatabase>
#include<QMessageBox>
#include<QSqlRecord>
#include<QtSql>
#include<QDebug>
#include<QException>
#include<QFileInfo>
#include<QDialog>

class dbconnect
{
public:
   void connectDb();
   void close();


};

#endif // DBCONNECT_H
