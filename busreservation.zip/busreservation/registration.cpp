#include "registration.h"
#include "ui_registration.h"


registration::registration(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::registration)
{
    ui->setupUi(this);
}

registration::~registration()
{
    delete ui;
}

void registration:: setS_id(int id){
        this->s_id=id;
    QVariant var(s_id);
    sid = var.toString();



}
void registration:: setB_id(int id){


  this->bus_id=id;
    QVariant var(bus_id);
     bid = var.toString();

}


void registration::on_register_2_clicked()
{
    QString  username, userphone;
    username = ui->username->text();
    userphone = ui->userphone->text();
    try{
            db->close();
            db->connectDb();
            QSqlQuery query1;


            if(query1.exec("INSERT INTO user ( name,phone, bus_id, seat_id) VALUES ('"+username+"','"+userphone+"','"+bid+"','"+sid+"')")){

                QMessageBox::information(this,"Success","Your seat has been reserved succesfully");
                qDebug()<<"This is bus id:"<<bus_id;
                qDebug()<<"This is bus id:"<<s_id;

                this->close();

            }

            else {
               QMessageBox::information(this,"Not Success","Bus couldn't be added succesfully");
            }




    }catch(const char *msg){
                    throw msg;
    }


}


//void registration:: setS_id(int sid){
//    this->s_id=sid;

//}
//void registration:: setB_id(int bid){
//this->bus_id=bid;
//}

void registration::on_cancel_clicked()
{
    this->close();
}
