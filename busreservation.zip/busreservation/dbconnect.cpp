#include "dbconnect.h"

void dbconnect::connectDb(){

        try {
            QSqlDatabase db;
            db=QSqlDatabase::addDatabase("QSQLITE");
            qDebug()  <<  QSqlDatabase::drivers();
            db.setDatabaseName("/home/sijan/Desktop/bus.db");
            db.open();

         } catch (const char* msg) {
           throw msg ;
         }
    }

void dbconnect::close(){
    try {
        QSqlDatabase db;

        db.close();

     } catch (const char* msg) {
       throw msg ;
     }
}
