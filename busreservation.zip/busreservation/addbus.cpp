#include "addbus.h"
#include "ui_addbus.h"
#include <QException>

addBus::addBus(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::addBus)
{
    ui->setupUi(this);
}

addBus::~addBus()
{
    delete ui;
}

void addBus::on_pushButton_clicked()
{
    QString id,d_name,source,destination,arrival,departure;
    id = ui->id->text();
    d_name = ui->d_name->text();
    source = ui->source->text();
    destination = ui->destination->text();
    arrival = ui->arrival->text();
    departure = ui->departure->text();

    qDebug()<<id;
    qDebug()<<d_name;

    try{
            db->connectDb();
            QSqlQuery query1;


            if(query1.exec("INSERT INTO bus (id,d_name,source,dest,arrival,departure) VALUES ('"+id+"','"+d_name+"','"+source+"','"+destination+"','"+arrival+"','"+departure+"')")){

                QMessageBox::information(this,"Success","Bus added succesfully");
                this->close();

            }

            else {
               QMessageBox::information(this,"Not Success","Bus couldn't be added succesfully");
            }




    }catch(const char *msg){
                    throw msg;
    }

}
