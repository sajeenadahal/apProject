#include "showbus.h"
#include "ui_showbus.h"

showBus::showBus(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::showBus)
{
    ui->setupUi(this);
}

showBus::~showBus()
{
    delete ui;
}

void showBus::on_bus1_clicked()
{
    this->close();
    s=new seats(this);
    s->setId(1);
    s->show();

}



void showBus::on_bus2_clicked()
{
    this->close();
    s=new seats(this);
    s->setId(2);
    s->show();
}

void showBus::on_bus3_clicked()
{
    this->close();
    s=new seats(this);
    s->setId(3);
    s->show();
}

void showBus::on_bus4_clicked()
{
    this->close();
    s=new seats(this);
    s->setId(4);
    s->show();
}

void showBus::on_bus5_clicked()
{
    this->close();
    s=new seats(this);
    s->setId(5);
    s->show();
}

void showBus::on_pushButton_clicked()
{
    db->connectDb();
    QSqlQueryModel *model=new QSqlQueryModel();
        QSqlQuery *query=new QSqlQuery();
        query->prepare("SELECT * FROM bus");
        query->exec();

        model->setQuery(*query);
        ui->tableView->setModel(model);
        qDebug()<<(model->rowCount());

        db->close();
}
