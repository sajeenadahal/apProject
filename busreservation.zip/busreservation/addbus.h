#ifndef ADDBUS_H
#define ADDBUS_H
#include "dbconnect.h"
#include <QDialog>

namespace Ui {
class addBus;
}

class addBus : public QDialog
{
    Q_OBJECT

public:
    explicit addBus(QWidget *parent = 0);
    ~addBus();

private slots:
    void on_pushButton_clicked();

private:
    Ui::addBus *ui;
    dbconnect *db;
};

#endif // ADDBUS_H
