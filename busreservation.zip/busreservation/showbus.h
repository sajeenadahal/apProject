#ifndef SHOWBUS_H
#define SHOWBUS_H

#include <QDialog>
#include "seats.h"
#include "dbconnect.h"
namespace Ui {
class showBus;
}

class showBus : public QDialog
{
    Q_OBJECT

public:
    explicit showBus(QWidget *parent = 0);
    ~showBus();

private slots:
    void on_bus1_clicked();

    void on_bus2_clicked();

    void on_bus3_clicked();

    void on_bus4_clicked();

    void on_bus5_clicked();

    void on_pushButton_clicked();

private:
    Ui::showBus *ui;
    seats *s;
    dbconnect *db;
};

#endif // SHOWBUS_H
