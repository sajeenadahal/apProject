#ifndef REGISTRATION_H
#define REGISTRATION_H

#include <QDialog>
#include "dbconnect.h"
#include "QException"

namespace Ui {
class registration;
}

class registration : public QDialog
{
    Q_OBJECT

public:
    explicit registration(QWidget *parent = 0);
    void setS_id(int);
    void setB_id(int);
    ~registration();

private slots:
    void on_register_2_clicked();

    void on_cancel_clicked();

private:
    Ui::registration *ui;
    int bus_id;
    int s_id;
    dbconnect *db;
    QString bid, sid;
};

#endif // REGISTRATION_H
