#ifndef LOGINFORM_H
#define LOGINFORM_H

#include <QDialog>
#include "avaibus.h"
namespace Ui {
class loginform;
}

class loginform : public QDialog
{
    Q_OBJECT

public:
    explicit loginform(QWidget *parent = 0);
    ~loginform();

private slots:
    void on_buttonBox_accepted();

    void on_loginbtn_clicked();

private:
    Ui::loginform *ui;
    avaibus *av;
};

#endif // LOGINFORM_H
