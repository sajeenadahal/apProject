#include "avaibus.h"
#include "ui_avaibus.h"
#include<QException>

avaibus::avaibus(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::avaibus)
{
    ui->setupUi(this);
}

avaibus::~avaibus()
{
    delete ui;
}

void avaibus::on_pushButton_clicked()
{
this->close();
    add=new addBus(this);
    add->show();
}



void avaibus::on_pushButton_2_clicked()
{
  db->connectDb();
  QSqlQueryModel *model=new QSqlQueryModel();
      QSqlQuery *query=new QSqlQuery();
      query->prepare("SELECT * FROM bus");
      query->exec();

      model->setQuery(*query);
      ui->tableView->setModel(model);
      qDebug()<<(model->rowCount());

      db->close();
}

void avaibus::on_pushButton_3_clicked()
{
    db->connectDb();
    QSqlQueryModel *model=new QSqlQueryModel();
        QSqlQuery *query=new QSqlQuery();
        query->prepare("SELECT * FROM user");
        query->exec();

        model->setQuery(*query);
        ui->reserveView->setModel(model);
        qDebug()<<(model->rowCount());

        db->close();
}
