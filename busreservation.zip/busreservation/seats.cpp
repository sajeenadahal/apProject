#include "seats.h"
#include "ui_seats.h"
#include <QDebug>
#include <QMessageBox>

seats::seats(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::seats)
{
    ui->setupUi(this);
}

seats::~seats()
{
    delete ui;
}


void seats:: setId(int id){
    this->bus_id=id;
//    QMessageBox::information(this,"BUS ID ","This is id");
}

void seats::on_s1_clicked()
{

    //here write the code to retrieve the boolean value from database table called seats with seat id=1 and if it is zero
    //then execute the following codes.
    this->close();
    reg = new registration(this);
    reg->setB_id(bus_id);

    reg->setS_id(1);
    reg->show();
}



void seats::on_s2_clicked()
{
    this->close();
    reg = new registration(this);
    reg->setB_id(bus_id);
    reg->setS_id(3);
    reg->show();
}

void seats::on_s3_clicked()
{
    this->close();
    reg = new registration(this);
    reg->setB_id(bus_id);
    reg->setS_id(3);
    reg->show();
}

void seats::on_s4_clicked()
{
    this->close();
    reg = new registration(this);
    reg->setB_id(bus_id);
    reg->setS_id(4);
    reg->show();
}

void seats::on_s5_clicked()
{
    this->close();
    reg = new registration(this);
    reg->setB_id(bus_id);
    reg->setS_id(5);
    reg->show();
}

void seats::on_s6_clicked()
{
    this->close();
    reg = new registration(this);
    reg->setB_id(bus_id);
    reg->setS_id(6);
    reg->show();
}
