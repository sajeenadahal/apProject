#include "loginform.h"
#include "ui_loginform.h"

loginform::loginform(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::loginform)
{
    ui->setupUi(this);
}

loginform::~loginform()
{
    delete ui;
}



void loginform::on_loginbtn_clicked()
{
     this->close();
    QString name,password;
    name=ui->name->text();
    password=ui->password->text();

    if(name=="admin" && password=="useradmin"){
        av=new avaibus(this);
        av->show();

    }
}
